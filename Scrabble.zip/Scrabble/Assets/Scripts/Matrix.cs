﻿using UnityEngine;
using System.Collections;

public class Matrix : MonoBehaviour {
	public static int value;
	public static string word;
}
