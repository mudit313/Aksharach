using UnityEngine;
using System.Collections;

public class Point : MonoBehaviour {
	public int pt;
	public string Unicode;
	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
